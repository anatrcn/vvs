package com.minishop.shop.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.web.servlet.View;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
public class AdminControllerTests {

    @Mock
    private View view;

    @Mock
    private Model model;

    @InjectMocks
    MainController mainController;

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void whenGetLoginPage_then200WithContent() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get("/admin/login")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType("text/html;charset=UTF-8"))
                .andExpect(view().name("login"))
                .andExpect(content().string(containsString("Login (For Employee, Manager)")));
    }

    @Test
    public void successEmployeeLogin() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/j_spring_security_check")
                .param("userName", "employee1")
                .param("password", "123")).andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/accountInfo"));
    }

    @Test
    public void successManagerLogin() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/j_spring_security_check")
                .param("userName", "manager1")
                .param("password", "123")).andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/accountInfo"));
    }

    @Test
    public void wrongCredentials() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/j_spring_security_check")
                .param("userName", "employee12")
                .param("password", "123")).andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/login?error=true"));
    }
}
