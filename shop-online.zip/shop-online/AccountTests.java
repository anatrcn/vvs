package com.minishop.shop.repository;

import com.minishop.shop.dao.AccountDAO;
import com.minishop.shop.entity.Account;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ActiveProfiles("test")
@SpringBootTest
public class AccountTests {

    @Autowired
    AccountDAO accountDAO;

    @Test
    public void getManagerUserName() {
        Account account = accountDAO.findAccount("manager1");
        assertEquals("manager1", account.getUserName());
    }

    @Test
    public void getEmployeeUserName() {
        Account account = accountDAO.findAccount("employee1");
        assertEquals("employee1", account.getUserName());
    }

    @Test
    public void getManagerUserRole() {
        Account account = accountDAO.findAccount("manager1");
        assertEquals("ROLE_MANAGER", account.getUserRole());
    }

    @Test
    public void getEmployeeUserRole() {
        Account account = accountDAO.findAccount("employee1");
        assertEquals("ROLE_EMPLOYEE", account.getUserRole());
    }
}
