package com.minishop.shop.repository;

import com.minishop.shop.dao.AccountDAO;
import com.minishop.shop.dao.ProductDAO;
import com.minishop.shop.entity.Account;
import com.minishop.shop.entity.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ActiveProfiles("test")
@SpringBootTest
public class ProductTests {

    @Autowired
    ProductDAO productDAO;

    @Test
    public void getProductCodeTest() {
        Product product = productDAO.findProduct("S001");
        assertEquals("S001", product.getCode());
    }

    @Test
    public void getProductPriceTest() {
        Product product = productDAO.findProduct("S001");
        assertEquals(50.0, product.getPrice());
    }

}
